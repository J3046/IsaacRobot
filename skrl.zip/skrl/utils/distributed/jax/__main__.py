from . import launcher


if __name__ == "__main__":
    launcher.launch()
