from skrl.trainers.torch.base import Trainer, generate_equally_spaced_scopes  # isort:skip

from skrl.trainers.torch.parallel import ParallelTrainer
from skrl.trainers.torch.sequential import SequentialTrainer
from skrl.trainers.torch.step import StepTrainer
