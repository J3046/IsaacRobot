from typing import List, Optional, Union

import copy
import sys
import tqdm
import time
import math
import torch

from skrl.agents.torch import Agent
from skrl.envs.wrappers.torch import Wrapper
from skrl.trainers.torch import Trainer

import os, re
from pathlib import Path


# fmt: off
SEQUENTIAL_TRAINER_DEFAULT_CONFIG = {
    "timesteps": 100000,                 # total env steps
    "headless": False,                   # render or not
    "disable_progressbar": False,        # tqdm bar
    "close_environment_at_exit": True,
    "environment_info": "episode",
    "stochastic_evaluation": False,
    "init_at_random_ep_len": False,
    "log_dir": None,
}
# fmt: on


class SequentialTrainer(Trainer):
    def __init__(
        self,
        env: Wrapper,
        agents: Union[Agent, List[Agent]],
        agents_scope: Optional[List[int]] = None,
        cfg: Optional[dict] = None,
    ) -> None:
        _cfg = copy.deepcopy(SEQUENTIAL_TRAINER_DEFAULT_CONFIG)
        _cfg.update(cfg if cfg is not None else {})
        agents_scope = agents_scope if agents_scope is not None else []
        super().__init__(env=env, agents=agents, agents_scope=agents_scope, cfg=_cfg)

        # init agents
        if self.num_simultaneous_agents > 1:
            for agent in self.agents:
                agent.init(trainer_cfg=self.cfg)
        else:
            self.agents.init(trainer_cfg=self.cfg)

        self._rsl_start_time = time.time()
        self._rsl_total_timesteps = 0
        self._rsl_it = 0
        self._avg_iter_time = None
        self._did_stagger = False  

        self._log_fp = None
        self._log_path = None
        try:
            hydra_dir, job_name = None, None
            try:
                from hydra.core.hydra_config import HydraConfig
                hc = HydraConfig.get()
                hydra_dir = getattr(hc.runtime, "output_dir", None)
                job_name  = getattr(hc.job, "name", None)  # e.g. ppo_torch / hydra / main
            except Exception:
                pass
            if hydra_dir is None:
                hydra_dir = os.getenv("HYDRA_RUN_DIR", None)

            p = Path(hydra_dir) if hydra_dir else Path.cwd()  # .../outputs/YYYY-MM-DD/HH-MM-SS
            date_part = (p.parent.name if p.parent and p.parent.name else time.strftime("%Y-%m-%d"))
            time_part = (p.name if p.name and p.name != "." else time.strftime("%H-%M-%S"))
            timestamp = f"{date_part}_{time_part}"

            project_root = p.parents[2] if hydra_dir and len(p.parents) >= 3 else Path.cwd()

            def _snake(s: str) -> str:
                return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s).lower()

            task_name = None
            try:
                agent0 = self.agents[0] if isinstance(self.agents, list) else self.agents
                exp_cfg = getattr(agent0, "cfg", {}).get("experiment", {}) if hasattr(agent0, "cfg") else {}
                if isinstance(exp_cfg, dict):
                    task_name = exp_cfg.get("directory") or exp_cfg.get("experiment_name")
            except Exception:
                pass
            if not task_name:
                env0 = getattr(self.env, "unwrapped", self.env)
                task_name = getattr(env0, "name", None)
                if not task_name:
                    task_name = _snake(type(env0).__name__) 

            algo = None
            if job_name and job_name not in ("hydra", "main"):
                algo = job_name
            if not algo:
                agent0 = self.agents[0] if isinstance(self.agents, list) else self.agents
                algo = (getattr(agent0, "__class__", type(agent0)).__name__).lower()
            if "torch" not in algo:
                algo = f"{algo}_torch"

            base_dir = project_root / "logs" / "skrl" / task_name / f"{timestamp}_{algo}"
            base_dir.mkdir(parents=True, exist_ok=True)

            self._log_path = str(base_dir / "train.log")
            self._log_fp = open(self._log_path, "a", buffering=1, encoding="utf-8")
            print(f"[skrl] Logging to: {os.path.abspath(self._log_path)}")
        except Exception as e:
            print(f"[skrl][WARN] Failed to open experiment train.log: {e}")
            self._log_fp = None


    def _log_block(self, text: str):
        print(text)
        fp = getattr(self, "_log_fp", None)
        if fp:
            try:
                fp.write(text + "\n")
                fp.flush()
            except Exception:
                pass


    def _rsl_mean_action_std(self, agent):
        try:
            if hasattr(agent.policy, "get_std"):
                std = agent.policy.get_std()
            else:
                std = getattr(agent.policy, "action_std", None)
            if std is None:
                return None
            return float(std.mean().item() if hasattr(std, "mean") else std)
        except Exception:
            return None

    def _rsl_merge_metrics(self, agents):
        if not isinstance(agents, list):
            agents = [agents]
        acc, cnt = {}, {}
        for a in agents:
            src = getattr(a, "metrics", None)
            if not isinstance(src, dict):
                continue
            for k, v in src.items():
                try:
                    fv = float(v if isinstance(v, (int, float))
                               else v.item() if hasattr(v, "item") else float(v))
                except Exception:
                    continue
                acc[k] = acc.get(k, 0.0) + fv
                cnt[k] = cnt.get(k, 0) + 1
        return {k: (acc[k] / max(cnt[k], 1)) for k in acc.keys()}

    def _steps_per_iter(self):
        envs = int(getattr(self.env, "num_envs", 1))
        if self.num_simultaneous_agents == 1:
            rolls = int(getattr(self.agents, "rollouts", getattr(self.agents, "cfg", {}).get("rollouts", 1)))
            return max(1, rolls) * envs

        rolls_list = [
            int(getattr(a, "rollouts", getattr(a, "cfg", {}).get("rollouts", 1)))
            for a in self.agents
        ] or [1]
        return max(1, min(rolls_list)) * envs

    def _total_iters(self, steps_per_iter: int):
        ts = int(self.cfg.get("timesteps", 0))
        if ts > 0 and steps_per_iter > 0:
            return max(1, math.ceil(ts / steps_per_iter))
        return 10000  

    def _maybe_stagger_episodes(self):

        if self._did_stagger or not self.cfg.get("init_at_random_ep_len", True):
            return
        try:
            base = getattr(self.env, "unwrapped", self.env)
            buf = getattr(base, "episode_length_buf", None)
            maxlen = getattr(base, "max_episode_length", None)
            if isinstance(buf, torch.Tensor) and (maxlen is not None):
                rnd = torch.randint_like(buf, high=int(maxlen))
                buf.copy_(rnd)  
                self._did_stagger = True
        except Exception:

            pass

    def _rsl_print_block(self, *, env, agents, it, total_iters,
                         steps_this_iter, collection_time, learning_time, loss_dict):
        pad, width = 35, 80
        iter_time = collection_time + learning_time

        self._avg_iter_time = (iter_time if self._avg_iter_time is None
                               else 0.9 * self._avg_iter_time + 0.1 * iter_time)
        fps = int(steps_this_iter / max(iter_time, 1e-9))
        self._rsl_total_timesteps += int(steps_this_iter)

        agent0 = agents[0] if isinstance(agents, list) else agents
        mean_std = self._rsl_mean_action_std(agent0)

        mgr = {}
        if hasattr(env, "pop_iteration_stats"):
            try:
                mgr = env.pop_iteration_stats() or {}
            except Exception:
                mgr = {}

        elapsed = time.time() - self._rsl_start_time
        remaining_iters = max(0, (total_iters or 0) - it)
        eta = remaining_iters * (self._avg_iter_time or iter_time)

        title = f" \033[1m Learning iteration {it}/{total_iters} \033[0m "
        s = "#" * width + "\n" + title.center(width) + "\n\n"
        s += f"{'Computation:':>{pad}} {fps:.0f} steps/s (collection: {collection_time:.3f}s, learning {learning_time:.3f}s)\n"
        if mean_std is not None:
            s += f"{'Mean action noise std:':>{pad}} {mean_std:.2f}\n"

        order = ["value_function_loss", "surrogate_loss", "entropy"]
        for k in order:
            if k in loss_dict:
                label = f"Mean {k.replace('_', ' ')}:" if 'loss' not in k else f"Mean {k}:"
                s += f"{label:>{pad}} {float(loss_dict[k]):.4f}\n"
        for k, v in loss_dict.items():
            if k in order:
                continue
            label = f"Mean {k} loss:" if 'loss' not in k.lower() else f"{k}:"
            s += f"{label:>{pad}} {float(v):.4f}\n"

        if "Mean reward" in mgr:
            s += f"{'Mean reward:':>{pad}} {mgr['Mean reward']:.2f}\n"
        if "Mean episode length" in mgr:
            s += f"{'Mean episode length:':>{pad}} {mgr['Mean episode length']:.2f}\n"

        for k in sorted(mgr.keys()):
            if k in ("Mean reward", "Mean episode length"):
                continue
            s += f"{k:>{pad}} {float(mgr[k]):.4f}\n"

        s += "-" * width + "\n"
        s += f"{'Total timesteps:':>{pad}} {self._rsl_total_timesteps}\n"
        s += f"{'Iteration time:':>{pad}} {iter_time:.2f}s\n"
        s += f"{'Time elapsed:':>{pad}} {time.strftime('%H:%M:%S', time.gmtime(elapsed))}\n"
        s += f"{'ETA:':>{pad}} {time.strftime('%H:%M:%S', time.gmtime(eta))}\n"

        self._log_block(s)


    def train(self) -> None:
        # set running mode
        if self.num_simultaneous_agents > 1:
            for agent in self.agents:
                agent.set_running_mode("train")
        else:
            self.agents.set_running_mode("train")

        states, infos = self.env.reset()
        self._maybe_stagger_episodes()

        steps_per_iter = self._steps_per_iter()
        total_iters = self._total_iters(steps_per_iter)

        if self.num_simultaneous_agents == 1:
            agent = self.agents

            for timestep in tqdm.tqdm(
                range(self.initial_timestep, self.timesteps),
                disable=self.disable_progressbar,
                file=sys.stdout,
            ):
                iter_t0 = time.time()

                # pre
                agent.pre_interaction(timestep=timestep, timesteps=self.timesteps)

                with torch.no_grad():
                    actions = agent.act(states, timestep=timestep, timesteps=self.timesteps)[0]

                    next_states, rewards, terminated, truncated, infos = self.env.step(actions)

                    # render
                    if not self.headless:
                        self.env.render()

                    # record transition
                    agent.record_transition(
                        states=states,
                        actions=actions,
                        rewards=rewards,
                        next_states=next_states,
                        terminated=terminated,
                        truncated=truncated,
                        infos=infos,
                        timestep=timestep,
                        timesteps=self.timesteps,
                    )

                    # log env info
                    if self.environment_info in infos:
                        for k, v in infos[self.environment_info].items():
                            if isinstance(v, torch.Tensor) and v.numel() == 1:
                                agent.track_data(f"Info / {k}", v.item())

                learn_t0 = time.time()
                agent.post_interaction(timestep=timestep, timesteps=self.timesteps)
                learning_time = time.time() - learn_t0
                iter_time = time.time() - iter_t0
                collection_time = max(iter_time - learning_time, 0.0)

                rolls = int(getattr(agent, "rollouts", getattr(agent, "cfg", {}).get("rollouts", 1)))
                if (timestep + 1) % max(1, rolls) == 0:
                    loss_dict = self._rsl_merge_metrics(agent)
                    self._rsl_print_block(
                        env=self.env,
                        agents=agent,
                        it=self._rsl_it + 1,
                        total_iters=total_iters,
                        steps_this_iter=steps_per_iter,
                        collection_time=collection_time,
                        learning_time=learning_time,
                        loss_dict=loss_dict,
                    )
                    self._rsl_it += 1

                # reset or forward
                if terminated.any() or truncated.any():
                    with torch.no_grad():
                        states, infos = self.env.reset()
                else:
                    states = next_states

            return 

        for timestep in tqdm.tqdm(
            range(self.initial_timestep, self.timesteps),
            disable=self.disable_progressbar,
            file=sys.stdout,
        ):
            iter_t0 = time.time()

            # pre
            for agent in self.agents:
                agent.pre_interaction(timestep=timestep, timesteps=self.timesteps)

            with torch.no_grad():
                # act
                actions = torch.vstack(
                    [
                        agent.act(states[scope[0]: scope[1]], timestep=timestep, timesteps=self.timesteps)[0]
                        for agent, scope in zip(self.agents, self.agents_scope)
                    ]
                )

                # step
                next_states, rewards, terminated, truncated, infos = self.env.step(actions)

                # render
                if not self.headless:
                    self.env.render()

                # record
                for agent, scope in zip(self.agents, self.agents_scope):
                    agent.record_transition(
                        states=states[scope[0]: scope[1]],
                        actions=actions[scope[0]: scope[1]],
                        rewards=rewards[scope[0]: scope[1]],
                        next_states=next_states[scope[0]: scope[1]],
                        terminated=terminated[scope[0]: scope[1]],
                        truncated=truncated[scope[0]: scope[1]],
                        infos=infos,
                        timestep=timestep,
                        timesteps=self.timesteps,
                    )

                # info
                if self.environment_info in infos:
                    for k, v in infos[self.environment_info].items():
                        if isinstance(v, torch.Tensor) and v.numel() == 1:
                            for agent in self.agents:
                                agent.track_data(f"Info / {k}", v.item())

            # learning
            learn_t0 = time.time()
            for agent in self.agents:
                agent.post_interaction(timestep=timestep, timesteps=self.timesteps)
            learning_time = time.time() - learn_t0
            iter_time = time.time() - iter_t0
            collection_time = max(iter_time - learning_time, 0.0)

            ref_rolls = min([
                int(getattr(agent, "rollouts", getattr(agent, "cfg", {}).get("rollouts", 1)))
                for agent in self.agents
            ] or [1])
            if (timestep + 1) % max(1, ref_rolls) == 0:
                loss_dict = self._rsl_merge_metrics(self.agents)
                self._rsl_print_block(
                    env=self.env,
                    agents=self.agents,
                    it=self._rsl_it + 1,
                    total_iters=total_iters,
                    steps_this_iter=steps_per_iter,
                    collection_time=collection_time,
                    learning_time=learning_time,
                    loss_dict=loss_dict,
                )
                self._rsl_it += 1

            # reset or forward
            if terminated.any() or truncated.any():
                with torch.no_grad():
                    states, infos = self.env.reset()
            else:
                states = next_states

    def eval(self) -> None:
        if self.num_simultaneous_agents > 1:
            for agent in self.agents:
                agent.set_running_mode("eval")
        else:
            self.agents.set_running_mode("eval")

        if self.num_simultaneous_agents == 1:
            if self.env.num_agents == 1:
                self.single_agent_eval()
            else:
                self.multi_agent_eval()
            return

        states, infos = self.env.reset()

        for timestep in tqdm.tqdm(
            range(self.initial_timestep, self.timesteps), disable=self.disable_progressbar, file=sys.stdout
        ):
            for agent in self.agents:
                agent.pre_interaction(timestep=timestep, timesteps=self.timesteps)

            with torch.no_grad():
                outputs = [
                    agent.act(states[scope[0]: scope[1]], timestep=timestep, timesteps=self.timesteps)
                    for agent, scope in zip(self.agents, self.agents_scope)
                ]
                actions = torch.vstack(
                    [
                        output[0] if self.stochastic_evaluation else output[-1].get("mean_actions", output[0])
                        for output in outputs
                    ]
                )

                next_states, rewards, terminated, truncated, infos = self.env.step(actions)

                if not self.headless:
                    self.env.render()

                for agent, scope in zip(self.agents, self.agents_scope):
                    agent.record_transition(
                        states=states[scope[0]: scope[1]],
                        actions=actions[scope[0]: scope[1]],
                        rewards=rewards[scope[0]: scope[1]],
                        next_states=next_states[scope[0]: scope[1]],
                        terminated=terminated[scope[0]: scope[1]],
                        truncated=truncated[scope[0]: scope[1]],
                        infos=infos,
                        timestep=timestep,
                        timesteps=self.timesteps,
                    )

                if self.environment_info in infos:
                    for k, v in infos[self.environment_info].items():
                        if isinstance(v, torch.Tensor) and v.numel() == 1:
                            for agent in self.agents:
                                agent.track_data(f"Info / {k}", v.item())

            for agent in self.agents:
                super(type(agent), agent).post_interaction(timestep=timestep, timesteps=self.timesteps)

            if terminated.any() or truncated.any():
                with torch.no_grad():
                    states, infos = self.env.reset()
            else:
                states = next_states
