from skrl.multi_agents.torch.base import MultiAgent
