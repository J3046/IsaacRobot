from skrl.multi_agents.jax.base import MultiAgent
