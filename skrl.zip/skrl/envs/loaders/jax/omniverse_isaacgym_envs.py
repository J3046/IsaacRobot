# since Omniverse Isaac Gym environments are implemented on top of PyTorch, the loader is the same

from skrl.envs.loaders.torch import load_omniverse_isaacgym_env
