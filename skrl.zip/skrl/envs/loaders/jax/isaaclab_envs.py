# since Isaac Lab environments are implemented on top of PyTorch, the loader is the same

from skrl.envs.loaders.torch import load_isaaclab_env
