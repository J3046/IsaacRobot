# since Bi-DexHands environments are implemented on top of PyTorch, the loader is the same

from skrl.envs.loaders.torch import load_bidexhands_env
