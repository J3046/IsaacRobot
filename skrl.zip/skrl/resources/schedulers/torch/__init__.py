from skrl.resources.schedulers.torch.kl_adaptive import KLAdaptiveLR


KLAdaptiveRL = KLAdaptiveLR  # known typo (compatibility with versions prior to 1.0.0)
