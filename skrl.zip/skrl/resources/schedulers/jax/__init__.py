from skrl.resources.schedulers.jax.kl_adaptive import KLAdaptiveLR, kl_adaptive


KLAdaptiveRL = KLAdaptiveLR  # known typo (compatibility with versions prior to 1.0.0)
