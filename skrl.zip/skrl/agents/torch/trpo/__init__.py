from skrl.agents.torch.trpo.trpo import TRPO, TRPO_DEFAULT_CONFIG
from skrl.agents.torch.trpo.trpo_rnn import TRPO_RNN
