from skrl.agents.torch.rpo.rpo import RPO, RPO_DEFAULT_CONFIG
from skrl.agents.torch.rpo.rpo_rnn import RPO_RNN
