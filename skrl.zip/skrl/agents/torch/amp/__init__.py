from skrl.agents.torch.amp.amp import AMP, AMP_DEFAULT_CONFIG
