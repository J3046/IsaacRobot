from skrl.agents.torch.a2c.a2c import A2C, A2C_DEFAULT_CONFIG
from skrl.agents.torch.a2c.a2c_rnn import A2C_RNN
