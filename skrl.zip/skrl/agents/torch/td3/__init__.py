from skrl.agents.torch.td3.td3 import TD3, TD3_DEFAULT_CONFIG
from skrl.agents.torch.td3.td3_rnn import TD3_RNN
