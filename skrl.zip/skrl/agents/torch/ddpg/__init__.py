from skrl.agents.torch.ddpg.ddpg import DDPG, DDPG_DEFAULT_CONFIG
from skrl.agents.torch.ddpg.ddpg_rnn import DDPG_RNN
