from skrl.agents.torch.dqn.ddqn import DDQN, DDQN_DEFAULT_CONFIG
from skrl.agents.torch.dqn.dqn import DQN, DQN_DEFAULT_CONFIG
