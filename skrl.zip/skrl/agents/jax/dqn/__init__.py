from skrl.agents.jax.dqn.ddqn import DDQN, DDQN_DEFAULT_CONFIG
from skrl.agents.jax.dqn.dqn import DQN, DQN_DEFAULT_CONFIG
