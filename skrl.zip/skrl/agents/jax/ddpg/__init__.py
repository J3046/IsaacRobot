from skrl.agents.jax.ddpg.ddpg import DDPG, DDPG_DEFAULT_CONFIG
