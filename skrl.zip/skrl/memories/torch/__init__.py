from skrl.memories.torch.base import Memory  # isort:skip

from skrl.memories.torch.random import RandomMemory
