# Copyright (c) 2022-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause

"""Wrapper to configure an environment instance to skrl environment.

The following example shows how to wrap an environment for skrl:

.. code-block:: python

    from isaaclab_rl.skrl import SkrlVecEnvWrapper

    env = SkrlVecEnvWrapper(env, ml_framework="torch")  # or ml_framework="jax"

Or, equivalently, by directly calling the skrl library API as follows:

.. code-block:: python

    from skrl.envs.torch.wrappers import wrap_env  # for PyTorch, or...
    from skrl.envs.jax.wrappers import wrap_env    # for JAX

    env = wrap_env(env, wrapper="isaaclab")

"""

from __future__ import annotations
from typing import Literal
from collections import deque, defaultdict
import numpy as np

from isaaclab.envs import ManagerBasedRLEnv, DirectRLEnv, DirectMARLEnv

def SkrlVecEnvWrapper(
    env: ManagerBasedRLEnv | DirectRLEnv | DirectMARLEnv,
    ml_framework: Literal["torch", "jax", "jax-numpy"] = "torch",
    wrapper: Literal["auto", "isaaclab", "isaaclab-single-agent", "isaaclab-multi-agent"] = "isaaclab",
):
    """Wrap Isaac Lab env for skrl AND collect per-iteration stats (rsl-rl style)."""


    if (
        not isinstance(env.unwrapped, ManagerBasedRLEnv)
        and not isinstance(env.unwrapped, DirectRLEnv)
        and not isinstance(env.unwrapped, DirectMARLEnv)
    ):
        raise ValueError(
            "The environment must inherit from ManagerBasedRLEnv, DirectRLEnv or DirectMARLEnv. "
            f"Environment type: {type(env)}"
        )

    if ml_framework.startswith("torch"):
        from skrl.envs.wrappers.torch import wrap_env
    elif ml_framework.startswith("jax"):
        from skrl.envs.wrappers.jax import wrap_env
    else:
        raise ValueError(
            f"Invalid ML framework for skrl: {ml_framework}. Available: 'torch', 'jax', 'jax-numpy'"
        )


    skrl_env = wrap_env(env, wrapper)


    skrl_env._iter_ep_returns: list[float] = []
    skrl_env._iter_ep_lengths: list[float] = []
    skrl_env._last_mean_return: float = 0.0   
    skrl_env._last_mean_length: float = 0.0
    skrl_env._mgr_sum = defaultdict(float)    
    skrl_env._mgr_cnt = defaultdict(int)


    skrl_env._rolling_rewards = deque(maxlen=100)
    skrl_env._rolling_lengths = deque(maxlen=100)

    num_envs = int(getattr(skrl_env, "num_envs", getattr(getattr(skrl_env, "unwrapped", skrl_env), "num_envs", 1)))
    skrl_env._ep_ret_running = np.zeros(num_envs, dtype=np.float64)
    skrl_env._ep_len_running = np.zeros(num_envs, dtype=np.int64)


    _orig_step = skrl_env.step

    def _to_numpy(x):
        try:
            import torch
            if isinstance(x, torch.Tensor):
                x = x.detach().cpu().numpy()
        except Exception:
            pass
        if np.isscalar(x):
            return np.array([x])
        return np.asarray(x)

    def _collect_manager_from_dict(d: dict):

        def _num(val):
            try:
                if isinstance(val, (int, float)):
                    return float(val)
                if hasattr(val, "mean"):
                    return float(val.mean())
                if hasattr(val, "__len__") and len(val) > 0:
                    return float(sum(val) / len(val))
            except Exception:
                pass
            return None

        for k, v in d.items():
            if k in ("r", "l"):
                continue
            if "/" in k or k.startswith("Episode_"):
                val = _num(v)
                if val is not None:
                    skrl_env._mgr_sum[k] += val
                    skrl_env._mgr_cnt[k] += 1

    def _aggregate_from_infos(infos):

        if not isinstance(infos, dict):
            return
        episode = infos.get("episode") or {}
        log = infos.get("log") or {}

        if isinstance(episode, dict):
            _collect_manager_from_dict(episode)
        if isinstance(log, dict):
            _collect_manager_from_dict(log)

        stats = infos.get("stats") or infos.get("manager_stats") or infos.get("episode_stats")
        if isinstance(stats, dict):
            _collect_manager_from_dict(stats)

    def _patched_step(actions):
        out = _orig_step(actions)

        if not isinstance(out, tuple):
            return out

        if len(out) == 5:
            obs, rew, term, trunc, infos = out
            done = _to_numpy(term).astype(bool)
            if trunc is not None:
                done = np.logical_or(done, _to_numpy(trunc).astype(bool))
        elif len(out) == 4:
            obs, rew, done, infos = out
            done = _to_numpy(done).astype(bool)
        else:
            return out

        r = _to_numpy(rew).reshape(-1)
        n = min(r.shape[0], skrl_env._ep_ret_running.shape[0], done.shape[0])
        if n > 0:
            skrl_env._ep_ret_running[:n] += r[:n]
            skrl_env._ep_len_running[:n] += 1

            if done[:n].any():
                idx = np.nonzero(done[:n])[0]
                for i in idx:
                    ret_i = float(skrl_env._ep_ret_running[i])
                    len_i = float(skrl_env._ep_len_running[i])
                    skrl_env._iter_ep_returns.append(ret_i)
                    skrl_env._iter_ep_lengths.append(len_i)
                    skrl_env._rolling_rewards.append(ret_i)
                    skrl_env._rolling_lengths.append(len_i)
                    skrl_env._ep_ret_running[i] = 0.0
                    skrl_env._ep_len_running[i] = 0

        try:
            _aggregate_from_infos(infos)
        except Exception:
            pass

        return out

    def _pop_iteration_stats():
        out = {}

        if skrl_env._iter_ep_returns:
            mean_r = sum(skrl_env._iter_ep_returns) / len(skrl_env._iter_ep_returns)
            skrl_env._last_mean_return = mean_r
        else:
            mean_r = skrl_env._last_mean_return

        if skrl_env._iter_ep_lengths:
            mean_l = sum(skrl_env._iter_ep_lengths) / len(skrl_env._iter_ep_lengths)
            skrl_env._last_mean_length = mean_l
        else:
            mean_l = skrl_env._last_mean_length

        out["Mean reward"] = float(mean_r)
        out["Mean episode length"] = float(mean_l)

        for k, s in list(skrl_env._mgr_sum.items()):
            c = skrl_env._mgr_cnt[k]
            if c > 0:
                out[k] = s / c

        skrl_env._iter_ep_returns.clear()
        skrl_env._iter_ep_lengths.clear()
        skrl_env._mgr_sum.clear()
        skrl_env._mgr_cnt.clear()

        return out

    skrl_env.step = _patched_step
    skrl_env.pop_iteration_stats = _pop_iteration_stats

    return skrl_env
