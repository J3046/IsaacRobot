# Copyright (c) 2024-2025, The Isaac Lab Project Developers.
# All rights reserved.
#
# SPDX-License-Identifier: Apache-2.0

"""Package containing implementation of Isaac Lab Mimic data generation."""

__version__ = "1.0.0"
